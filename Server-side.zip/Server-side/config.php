<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'augmonted');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'augmon');

